console.log("oi");
window.addEventListener('mouseup', wordSelected);

function wordSelected() {
  let selectedText = window.getSelection().toString().trim();
  console.log(selectedText.tagName);

  chrome.runtime.sendMessage(selectedText);

  }
