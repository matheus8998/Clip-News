

var word = '';


chrome.runtime.onMessage.addListener(receiver);
function receiver(response, request, sendResponse)
{

	word = response;
chrome.browserAction.onClicked.addListener(botaoClicado)

function botaoClicado(tab)
{
	if (tab = true) {
		console.log(word);
	$.ajax({
    method: "POST",
    url: "http://127.0.0.1:8080/",
    data: { name: "oibb"}
    })
	}
}
}
