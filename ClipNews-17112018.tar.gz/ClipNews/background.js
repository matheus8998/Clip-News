

var word = '';


chrome.runtime.onMessage.addListener(receiver);
function receiver(response, request, sendResponse)
{

	word = response;
chrome.browserAction.onClicked.addListener(botaoClicado)

function botaoClicado(tab)
{
	if (tab = true) {
	console.log(word);
	if( $('#word').val() ){
		//console.log("estou dentro do if");
        $.ajax({
            url     : 'savejson.php',
            method  : 'post',
            data    : { 'paragrafo': $('#word').val() },
            success : function( response ) {
                alert( response );
            }
        });
    }
	}
}
}
