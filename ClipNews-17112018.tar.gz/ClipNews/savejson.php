<?php
    $fp = fopen('clip_news.json', 'w');
    fwrite($fp, json_encode($_POST['paragrafo']));
    fclose($fp);
?>