console.log("oi");
var mensagem =  "teste";
//var funcionarios = '{"Marconildo":{"url": "mensagem","idade": 34}}';
 
//var funcionario = JSON.parse(funcionarios);
 
//console.log(funcionario.Marconildo);
//alert(funcionario.Marconildo.idade);

window.addEventListener('mouseup', wordSelected);

function wordSelected() {
  let selectedText = window.getSelection().toString().trim();
  console.log(selectedText);

  chrome.runtime.sendMessage(selectedText);

  }
