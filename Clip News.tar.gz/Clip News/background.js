

var word = '';

/*chrome.runtime.onMessage.addListener(receiver);
function receiver(response, request, sendResponse)
{
	console.log(response);
	word = response.text;
}

chrome.browserAction.onClicked.addListener(botaoClicado)

function botaoClicado(tab)
{
	console.log("inicio");
	if (tab = true) 
	{
	console.log("inicio if");
	chrome.runtime.onMessage.addListener(receiver);
	function receiver(response, request, sendResponse)
	{
	console.log("inicio func");
	console.log(response);
	word = response.text;
	console.log(word);
	console.log("fim func");
	}
	}
	console.log("fim if");
}
*/

chrome.runtime.onMessage.addListener(receiver);
function receiver(response, request, sendResponse)
{

	word = response.text;
chrome.browserAction.onClicked.addListener(botaoClicado)

function botaoClicado(tab)
{
	if (tab = true) {
		console.log(response);
	}
}
}
