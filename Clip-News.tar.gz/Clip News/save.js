chrome.runtime.onMessage.addListener(receiver);

console.log(receiver);

function mandaTexto()
{
	alert("clicou");
}